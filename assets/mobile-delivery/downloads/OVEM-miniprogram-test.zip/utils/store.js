const STORAGE_KEY = 'ovem-mini-state';

const PRODUCTS = [
  { id: 'p01', name: '精准备料辅助机器人', short: '精准备料', scene: '厨房', tier: '旗舰', price: '4,999', oneliner: '称量、切配、分份，跟着菜谱走', tags: ['菜谱联动', '食材识别', '低噪运行'] },
  { id: 'p02', name: '厨房台面巡航清洁机器人', short: '台面清洁', scene: '厨房', tier: '主力', price: '1,999', oneliner: '3cm 机身，钻得进调料架下', tags: ['蒸汽擦', '自主避障', '三模切换'] },
  { id: 'p03', name: '餐具智能归位机器人', short: '餐具归位', scene: '厨房', tier: '主力', price: '2,499', oneliner: '洗碗机之后，最后一步交给它', tags: ['柔性抓取', '视觉识别', '自定义分区'] },
  { id: 'p04', name: '冰箱食材管家机器人', short: '食材管家', scene: '厨房', tier: '引流', price: '899', oneliner: '掌心大小，在冰箱里自己盘点', tags: ['库存盘点', '临期提醒', '菜谱推荐'] },
  { id: 'p05', name: '桌面物品归位巡检机器人', short: '桌面巡检', scene: '客厅', tier: '引流', price: '599', oneliner: '夜里巡逻，早上桌面自己归位', tags: ['夜间静音', '物品识别', '拍照录入'] },
  { id: 'p06', name: '智能场景布置机器人', short: '场景布置', scene: '客厅', tier: '旗舰', price: '5,999', oneliner: '不是开关联动，是真的移动物体', tags: ['电动云台', '多场景', '语音触发'] },
  { id: 'p07', name: '全屋空气治理巡航机器人', short: '空气治理', scene: '客厅', tier: '主力', price: '2,999', oneliner: '先找到污染源，再净化', tags: ['多传感', '静音 30dB', '香氛管理'] },
  { id: 'p08', name: '睡眠环境自适应机器人', short: '睡眠自适应', scene: '卧室', tier: '主力', price: '2,699', oneliner: '监测不是目的，调环境才是', tags: ['非接触监测', '环境联动', '起夜引导'] },
  { id: 'p09', name: '夜间陪护服务机器人', short: '夜间陪护', scene: '卧室', tier: '主力', price: '1,699', oneliner: '半夜口渴，不用起身', tags: ['恒温仓', '跌倒报警', '语音交互'] },
  { id: 'p10', name: '衣物折叠收纳机器人', short: '衣物折叠', scene: '卧室', tier: '主力', price: '2,999', oneliner: '丢进去，第二天自己叠好入柜', tags: ['自适应折叠', '负离子除螨', '嵌入衣柜'] },
  { id: 'p11', name: '衣柜抽屉精细化整理机器人', short: '抽屉整理', scene: '收纳', tier: '引流', price: '799', oneliner: '5cm 机身，进得去抽屉', tags: ['抽屉适配', '静电抓取', '语音查找'] },
  { id: 'p12', name: '浴室全域清洁消毒机器人', short: '浴室清洁', scene: '卫浴个护', tier: '主力', price: '2,399', oneliner: '墙面、玻璃、地面，一趟走完', tags: ['IPX8', '三步清洁', '紫外消毒'] },
  { id: 'p13', name: '美妆护肤品智能管理机器人', short: '美妆管理', scene: '卫浴个护', tier: '旗舰', price: '3,999', oneliner: '该冷的冷，该热的热，按顺序递到手', tags: ['双温区', '保质期识别', '护肤流程'] },
  { id: 'p14', name: '头皮深层护理机器人', short: '头皮护理', scene: '卫浴个护', tier: '旗舰', price: '4,299', oneliner: '先检测，再决定怎么护理', tags: ['显微检测', '柔性触头', '报告同步'] },
  { id: 'p15', name: '智能美甲定制机器人', short: '美甲定制', scene: '卫浴个护', tier: '旗舰', price: '4,599', oneliner: '0.1mm 精度，单手十分钟', tags: ['图案定制', '自动修形', '速干烤灯'] },
  { id: 'p16', name: '衣物晾晒收纳一体化机器人', short: '晾晒收纳', scene: '阳台玄关', tier: '主力', price: '2,899', oneliner: '取衣、晾晒、收回、叠好，一条线', tags: ['轨道安装', '柔性夹爪', '天气联动'] },
  { id: 'p17', name: '盆栽智能养护巡航机器人', short: '盆栽养护', scene: '阳台玄关', tier: '引流', price: '699', oneliner: '多盆巡检，还会搬着花盆追光', tags: ['多盆管理', '追光移动', '品种识别'] },
  { id: 'p18', name: '鞋履全能护理机器人', short: '鞋履护理', scene: '阳台玄关', tier: '引流', price: '899', oneliner: '先认材质，再决定怎么护理', tags: ['材质识别', '六步护理', '自主归位'] },
  { id: 'p19', name: '出行物品智能筹备机器人', short: '出行筹备', scene: '出行宠物', tier: '引流', price: '599', oneliner: '看日程、看天气，提前把包装好', tags: ['日程联动', '物品核查', '人脸确认'] },
  { id: 'p20', name: '宠物全托管陪护机器人', short: '宠物陪护', scene: '出行宠物', tier: '旗舰', price: '3,999', oneliner: '陪玩、喂食、清理，加班晚归也放心', tags: ['自主跟随', '定时喂食', '猫砂清理'] },
].map((product) => ({
  ...product,
  image: `/assets/products/${product.id}.jpg`,
  cutout: ['p07', 'p10', 'p12', 'p20'].includes(product.id) ? `/assets/cutouts/${product.id}.png` : '',
}));

const PROFILES = {
  p07: { workAction: '启动巡航', pauseAction: '暂停净化', modeLabel: '净化模式', modes: ['静音巡航', '标准净化', '深度净化'], idleLabel: '待机中', workingLabel: '巡航中', chargeLabel: '回充' },
  p12: { workAction: '启动清洁', pauseAction: '暂停清洁', modeLabel: '清洁模式', modes: ['标准清洁', '深度清洁', '快速清洁'], idleLabel: '已充满', workingLabel: '清洁中', chargeLabel: '回充' },
  p10: { workAction: '启动折叠', pauseAction: '暂停折叠', modeLabel: '折叠模式', modes: ['标准折叠', '轻柔折叠', '快速折叠'], idleLabel: '待机中', workingLabel: '折叠中', chargeLabel: '回充' },
  p20: { workAction: '开始陪护', pauseAction: '暂停陪护', modeLabel: '陪护模式', modes: ['陪玩模式', '看护模式', '喂食模式'], idleLabel: '待机中', workingLabel: '陪伴中', chargeLabel: '回充' },
  default: { workAction: '启动任务', pauseAction: '暂停任务', modeLabel: '工作模式', modes: ['标准模式', '静音模式', '深度模式'], idleLabel: '待机中', workingLabel: '运行中', chargeLabel: '回充' },
};

const INITIAL_DEVICES = [
  { id: 'dev-p07', productId: 'p07', room: '客厅', online: true, battery: 86, mode: '静音巡航', status: 'idle', progress: 0, lastActive: '2 分钟前' },
  { id: 'dev-p12', productId: 'p12', room: '浴室', online: true, battery: 100, mode: '深度清洁', status: 'idle', progress: 100, lastActive: '今天 14:20' },
  { id: 'dev-p20', productId: 'p20', room: '客厅', online: true, battery: 76, mode: '陪玩模式', status: 'working', progress: 68, lastActive: '正在陪护' },
  { id: 'dev-p10', productId: 'p10', room: '卧室', online: false, battery: 42, mode: '标准折叠', status: 'offline', progress: 0, lastActive: '昨天 21:10' },
];

const INITIAL_SCENES = [
  { id: 'scene-arrive', name: '回家模式', subtitle: '推门，空气先一步到家', description: '空气巡航自动启动，客厅灯带调至暖光，宠物陪护转入看护。', icon: '⌂', enabled: true, deviceIds: ['dev-p07', 'dev-p20'], schedule: '每天 18:00 — 22:00', lastRun: '今天 18:06', image: '/assets/hero.jpg' },
  { id: 'scene-clean', name: '离家清洁', subtitle: '门关上，清洁才开始', description: '浴室与厨房进入深度清洁，空气巡航同步处理异味。', icon: '✦', enabled: true, deviceIds: ['dev-p12', 'dev-p07'], schedule: '工作日 09:30', lastRun: '今天 09:32', image: '/assets/scene-clean.jpg' },
  { id: 'scene-night', name: '夜间静音', subtitle: '只留下 30 分贝的风', description: '空气治理切换静音巡航，衣物折叠延后到清晨执行。', icon: '☾', enabled: false, deviceIds: ['dev-p07', 'dev-p10'], schedule: '每天 23:00 — 07:00', lastRun: '昨天 23:02', image: '' },
  { id: 'scene-pet', name: '宠物看护', subtitle: '加班晚归，也有回应', description: '陪玩、喂食与猫砂清理按顺序执行，异常情况推送到消息中心。', icon: '◌', enabled: true, deviceIds: ['dev-p20'], schedule: '全天候', lastRun: '今天 16:40', image: '/assets/scene-pet.jpg' },
];

const INITIAL_NOTIFICATIONS = [
  { id: 'notice-1', title: '客厅空气已恢复清新', body: '全屋空气治理巡航完成，PM2.5 从 46 降至 12，巡航用时 18 分钟。', time: '10:32', read: false, type: 'device', deviceId: 'dev-p07' },
  { id: 'notice-2', title: '浴室深度清洁完成', body: '墙面、玻璃与地面已完成三步清洁，紫外消毒运行 12 分钟。', time: '09:58', read: false, type: 'device', deviceId: 'dev-p12' },
  { id: 'notice-3', title: '宠物看护已切换至看护模式', body: '拿铁正在休息，陪护机器人保持 1.5 米距离，环境音正常。', time: '09:14', read: true, type: 'scene', deviceId: 'dev-p20' },
  { id: 'notice-4', title: '滤芯寿命剩余 18%', body: '预计还可运行 11 天，建议在下一次巡航结束后更换滤芯。', time: '昨天 20:40', read: true, type: 'system', deviceId: 'dev-p07' },
];

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function createInitialState() {
  return {
    onboardingSeen: false,
    family: { name: '云杉里 12A', member: '林一', role: '家庭管理员' },
    notificationsEnabled: true,
    devices: clone(INITIAL_DEVICES),
    scenes: clone(INITIAL_SCENES),
    notifications: clone(INITIAL_NOTIFICATIONS),
  };
}

function loadState() {
  try {
    const data = wx.getStorageSync(STORAGE_KEY);
    if (data && data.devices && data.scenes && data.notifications) return data;
  } catch (error) {
    return null;
  }
  return null;
}

function saveState(state) {
  try {
    wx.setStorageSync(STORAGE_KEY, state);
  } catch (error) {
    // 本地存储不可用时保持页面内状态
  }
}

function getProduct(id) {
  return PRODUCTS.find((product) => product.id === id) || PRODUCTS[0];
}

function getProfile(productId) {
  return PROFILES[productId] || PROFILES.default;
}

function getUnreadCount(state) {
  return state.notifications.filter((notice) => !notice.read).length;
}

function statusText(device) {
  if (!device.online) return '离线';
  const profile = getProfile(device.productId);
  if (device.status === 'working') return profile.workingLabel;
  if (device.status === 'charging') return '回充中';
  return profile.idleLabel;
}

function toDeviceView(device) {
  const product = getProduct(device.productId);
  const profile = getProfile(device.productId);
  return {
    ...device,
    productName: product.name,
    short: product.short,
    tier: product.tier,
    tags: product.tags,
    modeLabel: profile.modeLabel,
    workAction: profile.workAction,
    pauseAction: profile.pauseAction,
    chargeLabel: profile.chargeLabel,
    image: product.image,
    cutout: product.cutout,
    statusText: statusText(device),
    modeInitial: (device.mode || ' ').slice(0, 1),
    isWorking: device.status === 'working',
    isCharging: device.status === 'charging',
  };
}

function addNotification(state, payload) {
  state.notifications.unshift({
    id: `notice-${Date.now()}`,
    title: payload.title,
    body: payload.body,
    time: '刚刚',
    read: false,
    type: payload.type || 'system',
    deviceId: payload.deviceId || '',
  });
}
module.exports = {
  STORAGE_KEY,
  PRODUCTS,
  PROFILES,
  createInitialState,
  loadState,
  saveState,
  getProduct,
  getProfile,
  getUnreadCount,
  statusText,
  toDeviceView,
  addNotification,
};
