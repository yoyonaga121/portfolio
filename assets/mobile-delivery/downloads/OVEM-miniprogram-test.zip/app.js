const store = require('./utils/store');

App({
  globalData: {
    state: null,
    statusBarHeight: 24,
  },

  onLaunch() {
    let state = store.loadState();
    if (!state) {
      state = store.createInitialState();
      store.saveState(state);
    }
    this.globalData.state = state;
    try {
      const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync();
      this.globalData.statusBarHeight = info.statusBarHeight || 24;
    } catch (error) {
      this.globalData.statusBarHeight = 24;
    }
  },

  getState() {
    if (!this.globalData.state) {
      this.globalData.state = store.loadState() || store.createInitialState();
    }
    return this.globalData.state;
  },

  setState(next) {
    this.globalData.state = next;
    store.saveState(next);
  },

  resetState() {
    const next = store.createInitialState();
    this.globalData.state = next;
    store.saveState(next);
    return next;
  },
});
