const store = require('../../utils/store');

const FILTERS = [
  { key: 'all', label: '全部' },
  { key: '厨房', label: '厨房' },
  { key: '客厅', label: '客厅' },
  { key: '卧室', label: '卧室' },
  { key: '收纳', label: '收纳' },
  { key: '卫浴个护', label: '卫浴' },
  { key: '阳台玄关', label: '阳台玄关' },
  { key: '出行宠物', label: '出行宠物' },
];

const TIER_CLASS = {
  旗舰: 'tier--flagship',
  主力: 'tier--main',
  引流: 'tier--entry',
};

Page({
  data: {
    statusBarHeight: 24,
    filters: FILTERS,
    activeFilter: 'all',
    keyword: '',
    products: [],
    total: 0,
  },

  onLoad(options) {
    this.allProducts = store.PRODUCTS.map((product) => ({
      ...product,
      tierClass: TIER_CLASS[product.tier] || 'tier--main',
    }));
    const initial = {};
    if (options && options.scene && FILTERS.some((filter) => filter.key === options.scene)) {
      initial.activeFilter = options.scene;
    }
    if (options && options.focus) {
      const focused = this.allProducts.find((product) => product.id === options.focus);
      if (focused) {
        initial.activeFilter = 'all';
        initial.keyword = focused.name;
      }
    }
    this.setData({
      statusBarHeight: getApp().globalData.statusBarHeight || 24,
      products: this.allProducts,
      total: this.allProducts.length,
      ...initial,
    }, () => {
      if (initial.activeFilter || initial.keyword) this.applyFilter();
    });
  },

  chooseFilter(event) {
    this.setData({ activeFilter: event.currentTarget.dataset.key }, () => this.applyFilter());
  },

  onSearch(event) {
    this.setData({ keyword: event.detail.value }, () => this.applyFilter());
  },

  clearSearch() {
    this.setData({ keyword: '' }, () => this.applyFilter());
  },

  applyFilter() {
    const { activeFilter, keyword } = this.data;
    const normalized = keyword.trim().toLowerCase();
    const products = this.allProducts.filter((product) => {
      const categoryMatch = activeFilter === 'all' || product.scene === activeFilter;
      if (!categoryMatch) return false;
      if (!normalized) return true;
      return [product.name, product.short, product.oneliner, product.scene, ...product.tags]
        .join(' ')
        .toLowerCase()
        .includes(normalized);
    });
    this.setData({ products });
  },

  openProduct(event) {
    const id = event.currentTarget.dataset.id;
    const product = this.allProducts.find((item) => item.id === id);
    if (!product) return;
    wx.showModal({
      title: product.name,
      content: `${product.oneliner}\n\n场景：${product.scene} · 定位：${product.tier} · 参考价：¥${product.price}\n\n这是 OVEM 概念产品目录，暂未接入购买流程。`,
      showCancel: false,
      confirmText: '知道了',
    });
  },

  goBack() {
    const pages = getCurrentPages();
    if (pages.length > 1) {
      wx.navigateBack();
    } else {
      wx.reLaunch({ url: '/pages/home/index' });
    }
  },
});
