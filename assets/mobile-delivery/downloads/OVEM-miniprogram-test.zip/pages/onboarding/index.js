const store = require('../../utils/store');

Page({
  data: {
    statusBarHeight: 24,
    step: 0,
    deviceCount: 4,
    dotIndexes: [0, 1, 2],
    steps: [
      { title: '接入设备', desc: '扫码或选择型号', glyph: '◉' },
      { title: '选择房间', desc: '客厅 / 卧室 / 浴室', glyph: '⌂' },
      { title: '开始工作', desc: '状态实时回传', glyph: '✓' },
    ],
    scenes: [
      { title: '回家模式', desc: '空气 / 灯光 / 陪伴', glyph: '⌂' },
      { title: '离家清洁', desc: '浴室 / 厨房 / 空气', glyph: '✦' },
      { title: '夜间静音', desc: '30dB / 低干扰', glyph: '☾' },
      { title: '宠物看护', desc: '陪玩 / 喂食 / 清理', glyph: '◌' },
    ],
  },

  onLoad(options) {
    const app = getApp();
    const state = app.getState();
    const reopen = options && options.reopen === '1';
    this.redirect = options && options.from === 'profile' ? '/pages/profile/index' : '/pages/home/index';
    if (state.onboardingSeen && !reopen) {
      wx.reLaunch({ url: '/pages/home/index' });
      return;
    }
    this.setData({
      statusBarHeight: app.globalData.statusBarHeight || 24,
      deviceCount: state.devices.length,
    });
  },

  next() {
    if (this.data.step < 2) {
      this.setData({ step: this.data.step + 1 });
      return;
    }
    this.finish();
  },

  skip() {
    this.finish();
  },

  finish() {
    const app = getApp();
    const state = app.getState();
    state.onboardingSeen = true;
    app.setState(state);
    wx.reLaunch({ url: this.redirect || '/pages/home/index' });
  },
});
