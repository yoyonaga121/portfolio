const store = require('../../utils/store');

const FEATURED_IDS = ['p07', 'p12', 'p10', 'p20'];
const SOLUTIONS = [
  { id: 'kitchen', title: '餐厨料理', desc: '备料、台面清洁与餐具归位，串成一条动线。', image: '/assets/scene-clean.jpg', scene: '厨房' },
  { id: 'pet', title: '宠物起居', desc: '陪玩、喂食与猫砂清理，晚归也有回应。', image: '/assets/scene-pet.jpg', scene: '出行宠物' },
  { id: 'storage', title: '收纳整理', desc: '衣物、鞋履与出行物品，各自回到该在的位置。', image: '/assets/hero.jpg', scene: '收纳' },
];

Page({
  data: {
    statusBarHeight: 24,
    activeTab: 'home',
    unread: 0,
    onlineCount: 0,
    deviceCount: 0,
    family: {},
    heroFeatured: [],
    allProducts: [],
    happening: [],
    solutions: SOLUTIONS,
    storyValues: [
      { title: '不是更像人', desc: '把动作做完整，而不是只做一个会说话的屏幕。' },
      { title: '不是更多开关', desc: '让设备按顺序协同，把一段家务真正交出去。' },
      { title: '不是更复杂', desc: '一个家庭、一个入口、一次认领，剩下交给场景。' },
    ],
  },

  onLoad() {
    this.setData({ statusBarHeight: getApp().globalData.statusBarHeight || 24 });
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    const app = getApp();
    const state = app.getState();
    const allProducts = store.PRODUCTS.map((product) => {
      const device = state.devices.find((item) => item.productId === product.id);
      return {
        ...product,
        paired: Boolean(device),
        online: device ? device.online : false,
        room: device ? device.room : '',
        mode: device ? device.mode : '',
      };
    });
    const featured = FEATURED_IDS.map((id) => allProducts.find((item) => item.id === id)).filter(Boolean);
    const happening = state.scenes
      .filter((scene) => scene.enabled)
      .slice(0, 2)
      .map((scene) => ({ ...scene, deviceCount: scene.deviceIds.length }));

    this.setData({
      unread: store.getUnreadCount(state),
      deviceCount: state.devices.length,
      onlineCount: state.devices.filter((device) => device.online).length,
      family: state.family,
      heroFeatured: featured,
      allProducts,
      happening,
    });
  },

  selectTab(event) {
    const tab = event.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
    wx.pageScrollTo({ scrollTop: 0, duration: 0 });
  },

  openMessages() {
    wx.reLaunch({ url: '/pages/messages/index' });
  },

  openDevices() {
    wx.reLaunch({ url: '/pages/devices/index' });
  },

  openScenes() {
    wx.reLaunch({ url: '/pages/scenes/index' });
  },

  openCatalog() {
    wx.navigateTo({ url: '/pages/catalog/index' });
  },

  openProduct(event) {
    const id = event.currentTarget.dataset.id;
    const state = getApp().getState();
    const device = state.devices.find((item) => item.productId === id);
    if (device) {
      wx.navigateTo({ url: `/pages/device/index?id=${device.id}` });
    } else {
      wx.navigateTo({ url: `/pages/catalog/index?focus=${id}` });
    }
  },

  openSolution(event) {
    const scene = event.currentTarget.dataset.scene;
    wx.navigateTo({ url: `/pages/catalog/index?scene=${scene}` });
  },

  onPullDownRefresh() {
    this.refresh();
    wx.stopPullDownRefresh();
  },
});
