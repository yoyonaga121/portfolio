const store = require('../../utils/store');

Page({
  data: {
    statusBarHeight: 24,
    family: {},
    devices: [],
    unread: 0,
    onlineCount: 0,
    deviceCount: 0,
    activeScenes: 0,
    averageBattery: 0,
  },

  onLoad() {
    this.setData({ statusBarHeight: getApp().globalData.statusBarHeight || 24 });
  },

  onShow() {
    const state = getApp().getState();
    const devices = state.devices.map(store.toDeviceView);
    const online = state.devices.filter((device) => device.online).length;
    const averageBattery = Math.round(
      state.devices.reduce((sum, device) => sum + device.battery, 0) / Math.max(1, state.devices.length),
    );
    this.setData({
      family: state.family,
      devices,
      unread: store.getUnreadCount(state),
      onlineCount: online,
      deviceCount: state.devices.length,
      activeScenes: state.scenes.filter((scene) => scene.enabled).length,
      averageBattery,
    });
  },

  openCatalog() {
    wx.navigateTo({ url: '/pages/catalog/index' });
  },

  openDevice(event) {
    wx.navigateTo({ url: `/pages/device/index?id=${event.currentTarget.dataset.id}` });
  },

  openMessages() {
    wx.reLaunch({ url: '/pages/messages/index' });
  },

  onPullDownRefresh() {
    this.onShow();
    wx.stopPullDownRefresh();
  },
});
