const store = require('../../utils/store');

Page({
  data: {
    statusBarHeight: 24,
    scenes: [],
    unread: 0,
    enabledCount: 0,
  },

  onLoad() {
    this.setData({ statusBarHeight: getApp().globalData.statusBarHeight || 24 });
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    const state = getApp().getState();
    this.setData({
      scenes: state.scenes.map((scene) => ({ ...scene, deviceCount: scene.deviceIds.length })),
      unread: store.getUnreadCount(state),
      enabledCount: state.scenes.filter((scene) => scene.enabled).length,
    });
  },

  toggleScene(event) {
    const id = event.currentTarget.dataset.id;
    const enabled = event.detail.value;
    const app = getApp();
    const state = app.getState();
    const scene = state.scenes.find((item) => item.id === id);
    if (!scene) return;
    scene.enabled = enabled;
    app.setState(state);
    this.refresh();
    wx.showToast({ title: enabled ? '场景已启用' : '场景已暂停', icon: 'none' });
  },

  runScene(event) {
    const id = event.currentTarget.dataset.id;
    const app = getApp();
    const state = app.getState();
    const scene = state.scenes.find((item) => item.id === id);
    if (!scene) return;
    scene.lastRun = '刚刚执行';
    scene.enabled = true;
    store.addNotification(state, {
      title: `已执行「${scene.name}」`,
      body: `${scene.description} ${scene.deviceIds.length} 台设备已按顺序开始执行。`,
      type: 'scene',
      deviceId: scene.deviceIds[0] || '',
    });
    app.setState(state);
    this.refresh();
    wx.showToast({ title: '场景已开始执行', icon: 'success' });
  },

  openDevice(event) {
    const id = event.currentTarget.dataset.id;
    if (!id) return;
    wx.navigateTo({ url: `/pages/device/index?id=${id}` });
  },

  openMessages() {
    wx.reLaunch({ url: '/pages/messages/index' });
  },
});
