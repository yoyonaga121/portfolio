const store = require('../../utils/store');

Page({
  data: {
    statusBarHeight: 24,
    family: { name: '云杉里 12A', member: '林一', role: '家庭管理员' },
    stats: { devices: 0, online: 0, scenes: 0, unread: 0 },
    notificationsEnabled: true,
    version: '0.9.0 · 测试工程',
  },

  onLoad() {
    this.setData({ statusBarHeight: getApp().globalData.statusBarHeight || 24 });
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    const state = getApp().getState();
    this.setData({
      family: state.family,
      notificationsEnabled: state.notificationsEnabled,
      stats: {
        devices: state.devices.length,
        online: state.devices.filter((device) => device.online).length,
        scenes: state.scenes.filter((scene) => scene.enabled).length,
        unread: store.getUnreadCount(state),
      },
    });
  },

  toggleNotifications(event) {
    const app = getApp();
    const state = app.getState();
    state.notificationsEnabled = event.detail.value;
    app.setState(state);
    this.refresh();
    wx.showToast({
      title: event.detail.value ? '消息通知已开启' : '消息通知已关闭',
      icon: 'none',
    });
  },

  goDevices() {
    wx.reLaunch({ url: '/pages/devices/index' });
  },

  goScenes() {
    wx.reLaunch({ url: '/pages/scenes/index' });
  },

  goMessages() {
    wx.reLaunch({ url: '/pages/messages/index' });
  },

  goCatalog() {
    wx.navigateTo({ url: '/pages/catalog/index' });
  },

  restartOnboarding() {
    wx.navigateTo({ url: '/pages/onboarding/index?reopen=1&from=profile' });
  },

  showAbout() {
    wx.showModal({
      title: '关于 OVEM',
      content: 'OVEM 是光谷效应（Optics Valley Effect）的家庭机器人控制端概念应用。当前为交互测试工程，数据保存在本机，不连接真实设备。',
      showCancel: false,
      confirmText: '知道了',
    });
  },

  resetDemo() {
    wx.showModal({
      title: '恢复演示数据',
      content: '将清空本机改动，回到 4 台设备、4 个场景和初始消息，并重新进入启动引导。',
      confirmText: '恢复',
      success: (result) => {
        if (!result.confirm) return;
        getApp().resetState();
        wx.reLaunch({ url: '/pages/onboarding/index' });
      },
    });
  },
});
