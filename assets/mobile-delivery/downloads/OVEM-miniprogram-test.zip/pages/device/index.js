const store = require('../../utils/store');

Page({
  data: {
    statusBarHeight: 24,
    device: null,
    unread: 0,
    lastCommand: '等待你的第一条指令',
    modes: [],
    isWorking: false,
    isOffline: false,
  },

  onLoad(options) {
    this.deviceId = options.id;
    this.setData({ statusBarHeight: getApp().globalData.statusBarHeight || 24 });
    this.loadDevice();
  },

  loadDevice() {
    const app = getApp();
    const state = app.getState();
    const raw = state.devices.find((item) => item.id === this.deviceId);
    if (!raw) {
      wx.showToast({ title: '设备不存在', icon: 'none' });
      setTimeout(() => wx.reLaunch({ url: '/pages/devices/index' }), 500);
      return;
    }
    const profile = store.getProfile(raw.productId);
    const device = store.toDeviceView(raw);
    this.setData({
      device,
      unread: store.getUnreadCount(state),
      modes: profile.modes,
      isWorking: device.isWorking,
      isOffline: !device.online,
    });
  },

  back() {
    wx.navigateBack({
      fail: () => wx.reLaunch({ url: '/pages/devices/index' }),
    });
  },

  openCatalog() {
    wx.navigateTo({ url: '/pages/catalog/index' });
  },

  persistAndRefresh(message) {
    const app = getApp();
    const state = app.getState();
    app.setState(state);
    this.loadDevice();
    wx.showToast({ title: message, icon: 'none' });
  },

  toggleWork() {
    const app = getApp();
    const state = app.getState();
    const device = state.devices.find((item) => item.id === this.deviceId);
    if (!device) return;
    if (!device.online) {
      device.online = true;
      device.status = 'idle';
      device.lastActive = '刚刚';
      store.addNotification(state, {
        title: '设备已重新连接',
        body: '已恢复与家庭网络的连接，可以继续发送动作。',
        type: 'system',
        deviceId: device.id,
      });
      this.setData({ lastCommand: '重新连接 · 刚刚' });
      this.persistAndRefresh('设备已重新连接');
      return;
    }
    const profile = store.getProfile(device.productId);
    if (device.status === 'working') {
      device.status = 'idle';
      device.progress = 0;
      this.setData({ lastCommand: `${profile.pauseAction} · 刚刚` });
      this.persistAndRefresh(profile.pauseAction);
    } else {
      device.status = 'working';
      device.progress = 68;
      store.addNotification(state, {
        title: profile.workingLabel,
        body: `${device.room}的${store.getProduct(device.productId).short}机器人已开始执行任务。`,
        type: 'device',
        deviceId: device.id,
      });
      this.setData({ lastCommand: `${profile.workAction} · 刚刚` });
      this.persistAndRefresh(profile.workAction);
    }
  },

  charge() {
    const app = getApp();
    const state = app.getState();
    const device = state.devices.find((item) => item.id === this.deviceId);
    if (!device) return;
    device.status = 'charging';
    device.online = true;
    store.addNotification(state, {
      title: '已发送回充指令',
      body: `${device.room}的机器人正在返回充电座。`,
      type: 'device',
      deviceId: device.id,
    });
    this.setData({ lastCommand: '回充 · 正在返回充电座' });
    this.persistAndRefresh('已发送回充指令');
  },

  changeMode(event) {
    const mode = event.currentTarget.dataset.mode;
    const app = getApp();
    const state = app.getState();
    const device = state.devices.find((item) => item.id === this.deviceId);
    if (!device) return;
    if (!device.online) {
      wx.showToast({ title: '设备离线，先重新连接', icon: 'none' });
      return;
    }
    device.mode = mode;
    this.setData({ lastCommand: `${mode} · 刚刚` });
    this.persistAndRefresh(`已切换至${mode}`);
  },

  move(event) {
    const direction = event.currentTarget.dataset.direction;
    if (!this.data.device || this.data.isOffline) {
      wx.showToast({ title: '设备离线，先重新连接', icon: 'none' });
      return;
    }
    this.setData({ lastCommand: `${direction} · 0.5m · 刚刚` });
    wx.showToast({ title: `已发送「${direction}」`, icon: 'none' });
  },

  openMessages() {
    wx.reLaunch({ url: '/pages/messages/index' });
  },
});
