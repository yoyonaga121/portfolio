const store = require('../../utils/store');

const TYPE_META = {
  device: { icon: '◈', label: '设备' },
  scene: { icon: '⌂', label: '场景' },
  system: { icon: '⚙', label: '系统' },
};

Page({
  data: {
    statusBarHeight: 24,
    notices: [],
    allNotices: [],
    unread: 0,
    filter: 'all',
    filters: [
      { key: 'all', label: '全部' },
      { key: 'device', label: '设备' },
      { key: 'scene', label: '场景' },
      { key: 'system', label: '系统' },
    ],
  },

  onLoad() {
    this.setData({ statusBarHeight: getApp().globalData.statusBarHeight || 24 });
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    const state = getApp().getState();
    const allNotices = state.notifications.map((notice) => {
      const meta = TYPE_META[notice.type] || TYPE_META.system;
      return {
        ...notice,
        typeIcon: meta.icon,
        typeLabel: meta.label,
        typeClass: notice.type === 'device' ? 'notice-icon--blue' : notice.type === 'scene' ? 'notice-icon--green' : 'notice-icon--grey',
      };
    });
    this.setData({
      allNotices,
      notices: this.filterNotices(allNotices, this.data.filter),
      unread: store.getUnreadCount(state),
    });
  },

  filterNotices(notices, filter) {
    if (filter === 'all') return notices;
    return notices.filter((notice) => notice.type === filter);
  },

  chooseFilter(event) {
    const filter = event.currentTarget.dataset.key;
    this.setData({
      filter,
      notices: this.filterNotices(this.data.allNotices, filter),
    });
  },

  markAllRead() {
    const app = getApp();
    const state = app.getState();
    state.notifications.forEach((notice) => {
      notice.read = true;
    });
    app.setState(state);
    this.refresh();
    wx.showToast({ title: '已全部标为已读', icon: 'success' });
  },

  openNotice(event) {
    const id = event.currentTarget.dataset.id;
    const app = getApp();
    const state = app.getState();
    const notice = state.notifications.find((item) => item.id === id);
    if (!notice) return;
    notice.read = true;
    app.setState(state);
    this.refresh();
    if (notice.deviceId) {
      wx.navigateTo({ url: `/pages/device/index?id=${notice.deviceId}` });
    } else {
      wx.showToast({ title: '这条消息暂无关联设备', icon: 'none' });
    }
  },
});
