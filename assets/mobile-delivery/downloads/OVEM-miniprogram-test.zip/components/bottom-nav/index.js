Component({
  properties: {
    active: {
      type: String,
      value: 'home',
    },
    unread: {
      type: Number,
      value: 0,
    },
  },
  data: {
    items: [
      { id: 'home', label: '首页', icon: 'home', path: '/pages/home/index' },
      { id: 'devices', label: '设备', icon: 'devices', path: '/pages/devices/index' },
      { id: 'scenes', label: '场景', icon: 'scenes', path: '/pages/scenes/index' },
      { id: 'messages', label: '消息', icon: 'messages', path: '/pages/messages/index' },
      { id: 'profile', label: '我的', icon: 'profile', path: '/pages/profile/index' },
    ],
  },
  methods: {
    handleTap(event) {
      const id = event.currentTarget.dataset.id;
      if (id === this.data.active) return;
      const item = this.data.items.find((entry) => entry.id === id);
      if (!item) return;
      wx.reLaunch({ url: item.path });
    },
  },
});
